<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Centro Net</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>
    
  <form method="post" action="login.php" class="login">
    <p>
      <label for="login">Login:</label>
      <input type="text" name="login" id="login" >
    </p>

    <p>
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" >
    </p>
    <p>
        <p> ERRO!!! Usuário ou Senha Inválidos</p>
    </p>

    <p class="login-submit">
      <button type="submit" class="login-button">Login</button>
    </p>
  </form>
</body>
</html>
